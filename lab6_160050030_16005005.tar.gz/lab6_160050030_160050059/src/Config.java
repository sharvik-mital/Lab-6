
/**
 * Edit to provide your database credentials
 */
public class Config {
	public static final String url = "jdbc:postgresql://localhost:5590/whatasap";
	public static final String user = "sharvik";
	public static final String password = "";
}
